import { ActivityComponent } from './activity/activity.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { PlaceComponent } from './place/place.component';
import { Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'activities', component: ActivityComponent }];

@NgModule({
  declarations: [
    AppComponent,
    ActivityComponent,
    PlaceComponent
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
